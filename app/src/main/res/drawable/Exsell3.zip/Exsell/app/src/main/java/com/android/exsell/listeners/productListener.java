package com.android.exsell.listeners;

import com.android.exsell.models.Product;

public interface productListener {
    void onProductClicked(Product product, int position);
}
