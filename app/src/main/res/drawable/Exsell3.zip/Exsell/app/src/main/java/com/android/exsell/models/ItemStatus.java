package com.android.exsell.models;

import org.json.JSONObject;

public class ItemStatus {
    public static final JSONObject statusCode= new JSONObject();
    private ItemStatus() {}
}
